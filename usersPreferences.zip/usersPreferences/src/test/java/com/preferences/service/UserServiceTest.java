package com.preferences.service;

import com.preferences.dto.UserDto;
import com.preferences.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

public class UserServiceTest {

    @Mock
    UserRepository userRepository;

    @InjectMocks
    UserService userService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    @Test
    void saveUserTest() {
        UserDto userDto = new UserDto();
        userDto.setUserName("john");
        userDto.setUserTheme("dark");
        userDto.setUserSocialMediaPlatform("Twitter");

        when(userRepository.save(userDto)).thenReturn(userDto);

        UserDto savedPreference = userService.saveUser(userDto);

        assertEquals("john", savedPreference.getUserName());
        assertEquals("dark", savedPreference.getUserTheme());
        assertEquals("Twitter", savedPreference.getUserSocialMediaPlatform());
    }
    @Test
    void getUserTest() {
        UserDto userDto = new UserDto();
        userDto.setUserName("john");
        userDto.setUserTheme("dark");
        userDto.setUserSocialMediaPlatform("Twitter");

        when(userRepository.findByUserName("john")).thenReturn(userDto);

        Optional<UserDto> foundPreference = Optional.ofNullable(userService.getUser("john"));

        assertTrue(foundPreference.isPresent());
        assertEquals("john", foundPreference.get().getUserName());
    }
    @Test
    void deleteUserByIdTest() {
        userService.deleteUserById(1L);
        verify(userRepository, times(1)).deleteById(1L);
    }

}
