package com.preferences;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsersPreferencesApplicationTests {

	@Test
	void contextLoads() {
	}

}
