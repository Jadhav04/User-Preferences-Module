package com.preferences.controller;

import com.preferences.dto.UserDto;
import com.preferences.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


public class UserControllertest {

    @Mock
    UserService userService;
    @InjectMocks
    UserController userController;
    private MockMvc mockMvc;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(userController).build();
    }

    @Test
    void saveAndUpdateUserdetails() throws Exception {

        UserDto userDto = new UserDto();
        userDto.setUserName("john");
        userDto.setUserTheme("dark");
        userDto.setUserSocialMediaPlatform("Twitter");

        when(userService.saveUser(any(UserDto.class))).thenReturn(userDto);

        mockMvc.perform(MockMvcRequestBuilders.post("/users")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"userName\": \"john\", \"userTheme\": \"dark\", \"userSocialMediaPlatform\": \"Twitter\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.userName").value("john"))
                .andExpect(jsonPath("$.userTheme").value("dark"))
                .andExpect(jsonPath("$.userSocialMediaPlatform").value("Twitter"));
    }

    @Test
    void getuserTest() throws Exception {

        UserDto userDto = new UserDto();
        userDto.setUserName("john");
        userDto.setUserTheme("dark");
        userDto.setUserSocialMediaPlatform("Twitter");

        when(userService.getUser("john")).thenReturn(userDto);

        mockMvc.perform(MockMvcRequestBuilders.get("/users/john"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.userName").value("john"))
                .andExpect(jsonPath("$.userTheme").value("dark"))
                .andExpect(jsonPath("$.userSocialMediaPlatform").value("Twitter"));
    }

    @Test
    void deleteuserTest() throws Exception {


        mockMvc.perform(MockMvcRequestBuilders.delete("/users/delete/1"))
                .andExpect(status().isNoContent());

        verify(userService, times(1)).deleteUserById(1L);
    }
}
