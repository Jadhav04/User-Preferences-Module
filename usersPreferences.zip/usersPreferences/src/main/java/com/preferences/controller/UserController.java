package com.preferences.controller;

import com.preferences.dto.UserDto;
import com.preferences.service.UserService;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.License;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;


@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;
    @Operation(tags = "getUser API",description = "This api is used to fetch the user details",
    responses = {
    @ApiResponse(
            responseCode = "200",
            description = "user details fetched successfully"
    )}
    )
    @GetMapping("/{username}")
    public UserDto getUser(@PathVariable String username) {
        return userService.getUser(username);

    }
    @Operation(tags = "saveAndUpdateUserdetails API",description = "This api is used for save and update the user details",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "user details Saved/Updated  successfully"
                    )}
    )
    @PostMapping
    public ResponseEntity<UserDto> saveAndUpdateUserdetails(@RequestBody UserDto userdto) {
        UserDto savedUser = userService.saveUser(userdto);
        return ResponseEntity.ok(savedUser);
    }
    @Hidden
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteuser(@PathVariable long id) {
        userService.deleteUserById(id);
        return ResponseEntity.noContent().build();
    }
}
