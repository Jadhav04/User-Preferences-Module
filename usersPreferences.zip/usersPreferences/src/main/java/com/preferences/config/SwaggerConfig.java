package com.preferences.config;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.stereotype.Service;

@OpenAPIDefinition(info = @Info(title = "User Preference API",
        description = "This api is used for perform the operation on user data",
        summary = "All api perform user specific operations",
        termsOfService = "Terms & Condition applied..",
        contact = @Contact(name = "Sr. Developer",
                email = "abc.xyz@gmail.com",
                url = "www.abc.com"),
        license = @License(name = "Demo License"),
        version = "Api/V1"),
        servers = {
                @Server(description = "Dev  Env", url = "http://localhost:9090"),
                @Server(description = "Test  Env", url = "http://localhost:8080")
        }


)
public class SwaggerConfig {
}
