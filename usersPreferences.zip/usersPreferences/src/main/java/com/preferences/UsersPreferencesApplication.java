package com.preferences;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsersPreferencesApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsersPreferencesApplication.class, args);
		System.out.println("inside the spring boot project");
	}

}
