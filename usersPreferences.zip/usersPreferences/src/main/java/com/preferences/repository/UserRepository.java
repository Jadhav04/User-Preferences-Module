package com.preferences.repository;

import com.preferences.dto.UserDto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<UserDto, Long> {

    UserDto findByUserName(String userName);
}
