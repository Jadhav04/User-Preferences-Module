package com.preferences.service;

import com.preferences.dto.UserDto;
import com.preferences.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.security.PublicKey;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public UserDto getUser(String userName) {
        return userRepository.findByUserName(userName);
    }

    public UserDto saveUser(UserDto userDto) {
        return userRepository.save(userDto);
    }

    public void deleteUserById(Long id) {
        userRepository.deleteById(id);
    }

}
