package com.preferences.dto;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class UserDto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String userName;
    private String userTheme;
    private String userSocialMediaPlatform;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserTheme() {
        return userTheme;
    }

    public void setUserTheme(String userTheme) {
        this.userTheme = userTheme;
    }

    public String getUserSocialMediaPlatform() {
        return userSocialMediaPlatform;
    }

    public void setUserSocialMediaPlatform(String userSocialMediaPlatform) {
        this.userSocialMediaPlatform = userSocialMediaPlatform;
    }

    @Override
    public String toString() {
        return "UserDto{" + "id=" + id + ", userName='" + userName + '\'' + ", userTheme='" + userTheme + '\'' + ", userSocialMediaPlatform='" + userSocialMediaPlatform + '\'' + '}';
    }

}
